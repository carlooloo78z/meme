MEME DECK

Open Meme-Deck-Offline.html in a web browser. No installation or web server is needed.

Included:
- 768 playable sounds: 96 synthesized base effects plus 7 remixes of every effect.
- Remixes: deep and slow, turbo, echo, 8-bit, robot, reverse and stutter.
- Reactions, impacts, gaming, cartoon, sci-fi, utility and music effects.
- Version filters and 48 sounds per page for browsing the larger collection.
- Import multiple MP3, WAV, OGG, M4A and other browser-supported audio files.
- Import a whole folder or drag files onto the page.
- Search, categories, favorites, volume, playback speed and layered playback.
- Download individual sounds (original effects as WAV; imports in their original format).
- Download board: makes a self-contained HTML file including your imported sounds.
- Export/restore library backups in JSON format.
- Keyboard: 1-9 plays the first nine visible sounds; Escape stops; / searches.

GETTING THE ORIGINAL MEMES
The full InstantsMeme catalog and its original recordings are NOT bundled.
Its audio files could not be retrieved in the build environment.
Visit https://instants.meme/ on a permitted connection, download the clips you
want, then import those audio files into this board. Use Download board after
importing to make your complete collection portable. No catalog-size limit is
imposed; each imported file must be under 20 MB and browser memory/storage
limits apply. Large collections make the exported HTML correspondingly large.

OFFLINE USE
The board makes no external requests for playback. Fonts, code and original
effects are all local. Clicking the InstantsMeme link opens that website.
Imported files are kept in browser storage when available, and included in
downloaded boards/backups. Browser data may be cleared, so keep a downloaded
copy. A managed device can still restrict HTML files, downloads or audio.
This application does not disable iBoss or guarantee that it cannot be blocked.

PRIVACY
No analytics, accounts or uploads. All imports and playback happen locally.
The board does not run a local server, modify browser security or install software.

SOURCE
dist/index.html contains the complete application. Meme-Deck-Offline.html is
an identical standalone copy for convenient opening.

PUBLICATION
A private Site was registered, but publishing could not complete because this
session cannot reach the Site source repository. No live URL is available.
